The most difficult of this assignment was trying to figure out the regex so that Main_Page links and links containing ":" were ignored. 
The other issue was the amount of time the program took if I used a robot parser.
